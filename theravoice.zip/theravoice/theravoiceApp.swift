//
//  vertical_ai_hackathonApp.swift
//  vertical_ai_hackathon
//
//  Created by Andrew Blakeslee Moore on 10/20/24.
//

import SwiftUI

@main
struct theravoiceApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
